-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- ホスト: localhost:3306
-- 生成日時: 2023-01-16 17:37:05
-- サーバのバージョン： 5.7.24
-- PHP のバージョン: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `map_db`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `map_tables`
--

CREATE TABLE `map_tables` (
  `id` int(12) NOT NULL,
  `lid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lpw` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `lat` double(8,6) NOT NULL,
  `lon` double(9,6) NOT NULL,
  `img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `map_tables`
--

INSERT INTO `map_tables` (`id`, `lid`, `lpw`, `name`, `lat`, `lon`, `img`, `input_date`) VALUES
(2, 'aizu', '1205', '金閣寺', 35.039402, 135.729370, 'kinkakuji.jpg', '2022-11-07 11:58:32'),
(3, NULL, NULL, '南禅寺', 35.011986, 135.794388, 'nanzenzi.jpg', '2022-11-07 12:04:41'),
(4, NULL, NULL, '嵐山', 35.009580, 135.666400, 'arashiyama.jpg', '2022-11-07 12:06:06'),
(5, NULL, NULL, '東寺', 34.985504, 136.062256, 'tougi.jpg', '2022-11-08 03:20:18'),
(6, NULL, NULL, 'ディズニーランド', 35.635586, 139.884583, 'disnyland.jpg', '2022-11-08 03:22:46'),
(7, NULL, NULL, '道後温泉街', 33.850513, 132.784973, 'dogo.jpg', '2022-11-08 03:23:32'),
(8, NULL, NULL, '出雲大社', 35.334930, 132.720932, 'izumo.jpg', '2022-11-08 03:25:29'),
(9, NULL, NULL, '沖縄美ら海水族館', 26.694454, 127.878098, 'tyuraumi.jpg', '2022-11-08 03:25:29'),
(10, NULL, NULL, '白神山地', 40.469990, 140.130005, 'sirakamisanchi.jpg', '2022-11-08 03:29:24'),
(21, 'yui', '1205', 'ユニバーサル・スタジオ・ジャパン', 34.666496, 135.431824, NULL, '2022-12-17 13:06:49'),
(38, 'yui', '0410', '富士山', 35.357500, 138.730600, '6d3cba10c25d6a4597b944802fc0b699b2998706_MtFuji_FujiCity.jpg', '2022-12-17 15:46:45'),
(39, 'aizu', '0501', '富士急ハイランド', 35.487648, 138.779236, '65ff615a1a8d793394c6d3f6a8914edcf872e2eb_th.jpg', '2022-12-17 15:51:37'),
(44, NULL, NULL, 'ユニバーサル・スタジオ・ジャパン', 35.607404, 140.106537, 'dc70a2efe2bbda23377f663972af0d206aad33a6_R.jpg', '2022-12-19 11:09:19');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `map_tables`
--
ALTER TABLE `map_tables`
  ADD PRIMARY KEY (`id`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `map_tables`
--
ALTER TABLE `map_tables`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
