<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="css/main.css" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<style>div{padding: 10px;font-size:16px;}</style>
<title>ログイン</title>
</head>
<body>

<header>
  <nav class="navbar navbar-default">LOGIN</nav>
</header>

<!-- lLOGINogin_act.php は認証処理用のPHPです。 -->
<form name="form1" action="map_login_act.php" method="post">
ID:<input type="text" name="lid" />
<!-- lid = login id -->
PW:<input type="password" name="lpw" />
<!-- lid = login password -->
<input type="submit" value="LOGIN" />
</form>


</body>
</html>