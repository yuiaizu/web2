<?php

$id = $_GET["id"];

try {
    $pdo = new PDO('mysql:dbname=map_db;charset=utf8;host=localhost','root','root');
} catch (PDOException $e) {
    exit('DB Error'.$e->getMessage());
}


$sql = "SELECT * FROM map_tables WHERE id=:id";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(":id", $id);
$status = $stmt->execute();

//３．データ表示
$view=""; //表示用文字列を格納する変数
if($status==false) {
    //execute（SQL実行時にエラーがある場合）
    $error = $stmt->errorInfo();
    exit("*SQL Error:".$error[2]);
}else{
    $res = $stmt->fetch();//一行だけ取得する
}

?>
<!--２．HTML-->
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
<center>
  <title>更新</title>
  <style>label{display: block; padding: 10px;font-size:16px;}</style>
  <style>
  body{width:100%;height:100%;margin:0;padding:0;}
  #photarea{padding:5%;width:100%;background:black;}
  img{height:100px;}
  #haikei{height: 300;width: 200;}
  </style>
  <link rel="stylesheet" href="css/range.css">
  <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<!-- Head[Start] -->
<header>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
    <div class="previous"><a class="navbar-brand" href="map_new.html">新規アップロード</a></div>
      <ul class="pager">
      <li class="previous"><a href="index.html">現在地から画像をアップロード</a></li>
      <li class="previous"><a href="file_view.php">画像一覧</a></li>
      <li class="previous"><a href="map_kousin.php">更新/削除</a></li>
      <li class="next"><a href="#">マップ画面に戻る</a></li>
      </ul>
     </div>
  </nav>
</header>
<!-- Head[End] -->

<!-- Main[Start] -->

<form method="post" action="map_update.php">
  <div class="jumbotron">
   <fieldset>
    <legend>更新登録</legend>
     <label>名前:<input type="text" name="name" value="<?=$res["name"]?>"></label><br>
     <label>緯度:<input type="text" name="lat" value="<?=$res["lat"]?>"></label><br>
     <label>経度:<input type="text" name="lon" value="<?=$res["lon"]?>"></label><br>
     <label>LOGIN ID:<input type="text" name="lid" value="<?=$res["lid"]?>"></label><br>
     <label>LOGIN PASSWORD:<input type="text" name="lpw" value="<?=$res["lpw"]?>"></label><br>
     <input type="hidden" name="id" value="<?=$id?>">
     <input type="submit" value="送信">
    </fieldset>
  </div>
</form>
</center>
<!-- Main[End] -->

</body>
</html>



