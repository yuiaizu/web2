<?php
//1.  DB接続します
try {
    $pdo = new PDO('mysql:dbname=map_db;charset=utf8;host=localhost','root','root');
} catch (PDOException $e) {
    exit('DB Error'.$e->getMessage());
}

//２．テーブル名"gs_my_table"のSQLを作成
$sql = "SELECT * FROM map_tables ORDER BY id ASC";
$stmt = $pdo->prepare($sql);
$status = $stmt->execute();

//３．データ表示
$view=""; //表示用文字列を格納する変数
if($status==false) {
    //execute（SQL実行時にエラーがある場合）
    $error = $stmt->errorInfo();
    exit("*SQL Error:".$error[2]);
}else{
    //Selectデータで取得したレコードの数だけ自動でループする
    while( $res = $stmt->fetch(PDO::FETCH_ASSOC)){
        $view .= '<tr>';

        $view .= '<td>';
        //削除
        $view .= '<a href="map_delete.php?id='.$res["id"].'">';
        $view .= '<input type="submit" value="削除">';
        $view .= '</a>';
        
        $view .= '<td bgcolor="#dee3e7">';
        //更新
        $view .= '<a href="map_detail.php?id='.$res["id"].'">';
        $view .= '<input type="submit" value="更新">';
        $view .= '</a>';

        $view .= '</td>';
        $view .= '<td>'.$res["name"].'</td>';
        $view .= '<td bgcolor="#dee3e7">'.$res["lat"].'</td>';
        $view .= '<td>'.$res["lon"].'</td>';
        $view .= '<td bgcolor="#dee3e7">'.$res["lid"].'</td>';
        $view .= '<td>'.$res["lpw"].'</td>';
        $view .= '</tr>'.PHP_EOL;  //PHP_EOLは改行コード!!
    }
}
?>

<!-- 一行ずつ色変更 -->


<!DOCTYPE html>
<html>
<head>
<style>
    #photarea{padding:5%;width:100%;background:black;}
    img{height:200px;}
    </style>
    <link rel="stylesheet" href="css/range.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
        <meta charset="utf-8">
    <title>更新/削除</title>
    <style>
        td {
            border: 1px solid #ccc;
            padding: 5px;
        }
    </style>
</head>

<header>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
        <div class="previous"><a class="navbar-brand" href="map_new.html">新規アップロード</a></div>
        <ul class="pager">
        <li class="previous"><a href="index.html">現在地から画像をアップロード</a></li>
        <li class="previous"><a href="file_view.php">画像一覧</a></li>
        <li class="previous"><a href="map_kousin.php">更新/削除</a></li>
        <li class="next"><a href="map_view.php">マップ画面に戻る</a></li>
        </ul>
        </div>
    </nav>
</header>
<body>
    <center>
    <h1>更新/削除</h1>
    <table>
        <tr>
            <td></td>
            <td bgcolor="#dee3e7"></td>
            <td>名前</td>
            <td bgcolor="#dee3e7">緯度</td>
            <td>経度</td>
            <td bgcolor="#dee3e7">ログインID</td>
            <td>ログインPW</td>
        </tr>

        <?php
            echo $view;
        ?>

    </table>
</body>
</center>

</html>
