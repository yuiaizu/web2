<?php

$id = $_GET["id"];

try {
    $pdo = new PDO('mysql:dbname=map_db;charset=utf8;host=localhost','root','root');
} catch (PDOException $e) {
    exit('DB Error'.$e->getMessage());
}


$sql = "SELECT * FROM map_tables WHERE id=:id";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(":id", $id);
$status = $stmt->execute();

//３．データ表示
$view=""; //表示用文字列を格納する変数
if($status==false) {
    //execute（SQL実行時にエラーがある場合）
    $error = $stmt->errorInfo();
    exit("*SQL Error:".$error[2]);
}else{
    $res = $stmt->fetch();//一行だけ取得する
}


?>
<!--２．HTML-->
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>新規アップロード</title>
<style>
body{width:100%;height:100%;margin:0;padding:0;}
#photarea{padding:5%;width:100%;background:black;}
img{height:100px;}
</style>
<link rel="stylesheet" href="css/range.css">
<link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body id="main">
<center>
  <title>登録</title>
  <style>label{display: block; padding: 10px;font-size:16px;}</style>
</head>
<body>

<!-- Head[Start] -->
<header>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
    <div class="navbar-header"><a class="navbar-brand" href="#">新規アップロード</a></div>
      <ul class="pager">
      <li class="previous"><a href="index.html">現在地から画像をアップロード</a></li>
      <li class="next disabled"><a href="map_view.php">マップ画面に戻る</a></li>
      <li class="next disabled"><a href="file_view.php">画像一覧</a></li>
      </ul>
     </div>
  </nav>
</header>
<!-- Head[End] -->

<!-- Main[Start] -->

<form method="post" action="map_sinki.php">
  <div class="jumbotron">
   <fieldset>
    <legend>新規登録</legend>
     <label>名前:<input type="text" name="name" value="<?=$res["name"]?>"></label><br>
     <label>緯度:<input type="text" name="lat" value="<?=$res["lat"]?>"></label><br>
     <label>経度:<input type="text" name="lon" value="<?=$res["lon"]?>"></label><br>
     <label>LOGIN ID:<input type="text" name="lid" value="<?=$res["lid"]?>"></label><br>
     <label>LOGIN PASSWORD:<input type="text" name="lpw" value="<?=$res["lpw"]?>"></label>
     <input type="hidden" name="id" value="<?=$id?>">
     <p><a href="#" id="select_btn" class="btn btn-primary btn-lg">カメラ/写真選択</a></p>
            <form method="post" action="fileup.php" enctype="multipart/form-data">
                <input type="file" accept="image/*" capture="camera" id="image_file" value="" name="upfile" style="opacity:0;">
                <input type="text" name="name">
                <input type="submit" id="upload_btn" class="btn btn-success btn-lg" value="Fileアップロード">
            </form>
    </fieldset>
  </div>
</form>

</center>
<!-- Main[End] -->
    <!-- コンテンツ -->

    <script src="js/jquery-2.1.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        //非表示のinput type="file"をクリック
        $("#select_btn").on("click", function() {
            $("#image_file").trigger("click");
        });

        //File選択したら”Fileアップロード”ボタンを表示
        $("#image_file").on("change", function() {
              var file = $("#image_file").get(0).files[0];
              if ( file.size/1024 > 1500 ) {
                alert("OVER");
                return false;
              } else {
                console.log("OK");
              }
            $("#upload_btn").show();
        });
        
    </script>
    <script src="geolocation.js"></script>
</body>
</html>